%% Iterate
% This script tries to improve system Capacity by slightly changing vector
% N and checks if the system converged. Run Setup.m once before running
% this script.

%%
% defining delN
delN = [ 1  0 -1  0  0; % delN: set of Vectors that shifts N in different directions (Specific for 4 AP case)
    -1  0  1  0  0;
     1  0  0  0 -1;
    -1  0  0  0  1;
     1 -1  1 -1  0;
    -1  1 -1  1  0;
     1 -1  0 -1  1;
    -1  1  0  1 -1;
     0  1  0  1 -2;
     0 -1  0 -1  2;
     0  1 -1  1 -1;
     0 -1  1 -1  1;
     0  0  1  0 -1;
     0  0 -1  0  1];

[ll, ~] = size(delN);   % number of vectors in delN
 
%% initializing loop variables
delPerformance = zeros(1, ll);
maxDelPerformance = 0;
maxDelPerformanceid = 0;

for i1 = 1:ll
    newA = cell(1, 5);     % Tiles for each AP
    newT = zeros(8,8);     % Tile map
    
    % generating newN
    newN = N + delN(i1,:);
    % error check
    if sum(newN) ~= 64
        error('error: No of tiles is not correct. Check variable newN');
    end
    if newN(2) ~= newN(4)
        error('error: No of tiles for AP2 and AP4 are not same. Check variable newN');
    end
    
    if ~all(newN >= 0) % if value of newN goes out of bounds, skip to next
        delPerformance(i1) = -Inf;
        continue;
    end
    
    %% assign tiles to APs
    for i2 = [1 3 2 4 5]
        [newA{i2}, newT] = assignTiles(newN(i2), C{i2}, newT, i2);
    end
    
    %% analyze system
    [newAvgCapacity, newAvgCapacitiesPerAP, newAvgCapacitiesPerUser, newCount] = calcNetCapacity(newT, C);
    newCvariance = var(newAvgCapacitiesPerUser);
    
    %% calculate change in cost
    delPerformance(i1) = (newAvgCapacity / newCvariance) - (avgCapacity / Cvariance);
    % calculate max +ve change in cost
    if delPerformance(i1) > maxDelPerformance
        maxDelPerformance = delPerformance(i1);
        maxDelPerformanceid = i1;
    end
end

%% check for convergence
if maxDelPerformanceid == 0
    converged = true;
else
    converged = false;
end

% display debug info
if debug
    disp(delPerformance);
    if ~converged
        disp(maxDelPerformance);
        disp(maxDelPerformanceid);
    end
end

%% recalculate for new value of N
if ~converged
    N = N + delN(maxDelPerformanceid, :);
    A = cell(1, 5);     % Tiles for each AP
    T = zeros(8,8);     % Tile map
    
    % assign tiles to APs
    for i1 = [1 3 2 4 5]
        [A{i1}, T] = assignTiles(N(i1), C{i1}, T, i1);
    end
    
    % analyze system
    [avgCapacity, avgCapacitiesPerAP, avgCapacitiesPerUser, count] = calcNetCapacity(T, C);
    Cvariance = var(avgCapacitiesPerUser);
else
    fprintf('--------------- Converged ---------------\n');
end

%% display values
fprintf('Total average Capacity = %.4f, (var = %.4f)\n\n', avgCapacity, Cvariance);
fprintf('Avg Capacities per User:    %s\n', num2str(avgCapacitiesPerUser));
fprintf('Avg capacities per AP  :    %s\n', num2str(avgCapacitiesPerAP));
fprintf('Tiles being served     :    %s\n', num2str(count(1:4)));

if debug
    heatmap(T);
end