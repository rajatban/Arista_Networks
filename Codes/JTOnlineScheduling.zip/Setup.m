%% Setup (Initialize)
% This script initializes the simulation variables.

% clear workspace and set debug mode
if exist('debug', 'var') ~= 1
    disp('debug: false.')
    debug = false;
end

%% initialize variables
N = zeros(1, 5);    % No of tiles assigned to each AP
A = cell(1, 5);     % Tiles for each AP
T = zeros(8,8);     % Tile map
load('throughputCharts.mat', 'C');  % Load capacity matrix

% C{5} = zeros(8, 8);

% initializeN
N = [18 10 18 10 8];

% N = [10 14 10 14 16];
% N = [24 8 24 8 0];

% error check
if sum(N) ~= 64
    error('error: No of tiles is not correct. Check variable N');
end
if N(2) ~= N(4)
    error('error: No of tiles for AP2 and AP4 are not same. Check variable N');
end
if ~all(N >= 0)
    error('error: There is a negative value in N');
end

%% assign tiles to APs
for i1 = [1 3 2 4 5]
    [A{i1}, T] = assignTiles(N(i1), C{i1}, T, i1); % C is capacity matrix
end

%% analyze system
[avgCapacity, avgCapacitiesPerAP, avgCapacitiesPerUser, count] = calcNetCapacity(T, C);
Cvariance = var(avgCapacitiesPerUser);

%% display values
fprintf('Total average Capacity = %.4f, (var = %.4f)\n\n', avgCapacity, Cvariance);
fprintf('Avg Capacities per User:    %s\n', num2str(avgCapacitiesPerUser));
fprintf('Avg capacities per AP  :    %s\n', num2str(avgCapacitiesPerAP));
fprintf('Tiles being served     :    %s\n', num2str(count(1:4)));

if debug
    heatmap(T);
end