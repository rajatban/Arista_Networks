Scheduling Algorithm for JT scenario-

	This program finds the maximum throughput acheivable using the performance criteria of high capacity and low variance in throughputs among different users.
	This program is specificaly for a 4 AP system with 3 channels. Run the Main.m script The initial value of N can be changed in the Setup.m script. The capacity values are taken from the throughputCharts.mat file that contains capacity values for each AP with users in an 8x8 grid of side length 20m.

--------------------------------------------------------------------------------

Main script-

	This program initializes and iterated untill a convergence is obtained in the system. It runs Setup.m script and the repeatedly runs Iterate.m script until the program is converged. You can use the debug variable to inspect the evolution of the system step by step. If you want to manually run the simulation run the Setup.m and Iterate.m script manually from the same folder.
--------------------------------------------------------------------------------

Setpu script-

	This script initializes the simulation variables. You can change the initial value of N with some thing else, while following the constraints, when N is initialized.
--------------------------------------------------------------------------------

Iterate script-

	This script tries to improve system Capacity by slightly changing vector N and checks if the system converged. Run Setup.m once before running this script.
--------------------------------------------------------------------------------

throughputCharts.mat file-

	This mat file contains the Capacity values for different APs in a MatLab cell variable 'C' of size 1x5. C(1:4) contains the Non-Joint Transmission capacity values for all four APs and C(5) contains the Joint Transmission capacity values for the APs that can perform Joint Transmission.