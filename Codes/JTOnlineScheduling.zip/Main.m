%% Scheduling Algorithm for JT scenario
% This program finds the maximum throughput acheivable using the
% performance criteria of high capacity and low variance in throughputs
% among different users.
% This program is specificaly for a 4 AP system with 3 channels. The
% initial value of N can be changed in the Setup.m script. The capacity
% values are taken from the throughputCharts.mat file that contains
% capacity values for each AP with users in an 8x8 grid of side length 20m.

%% Main program
% This program initializes and iterated untill a convergence is obtained in
% the system.

clear;
%% setting variables
debug = false;

converged = false;
iteration = 1;

%% initializing
fprintf('---- initializing ----\n');
Setup;

%% iterating
while ~converged
    if debug
        pause(0.5);
    end
    fprintf('\n-> iteration %d\n', iteration);
    Iterate;
    iteration = iteration + 1;
end

% display end result graph
if ~debug
    heatmap(T);
end

% save the data to a file
% save('data/ConvergedVars_8x8_withJT.mat', 'N', 'T', 'avgCapacity', 'Cvariance', 'avgCapacitiesPerUser', 'avgCapacitiesPerAP', 'count');